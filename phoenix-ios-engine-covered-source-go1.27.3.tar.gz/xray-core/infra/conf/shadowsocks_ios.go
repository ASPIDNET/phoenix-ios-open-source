//go:build ios

package conf

import (
	"errors"
	"google.golang.org/protobuf/proto"
	ss2022 "github.com/xtls/xray-core/proxy/shadowsocks_2022"
)

// Keep JSON shape for dependent parsers, but reject Shadowsocks at build time.
type ShadowsocksUserConfig struct {
	Cipher   string   `json:"method"`
	Password string   `json:"password"`
	Level    byte     `json:"level"`
	Email    string   `json:"email"`
	Address  *Address `json:"address"`
	Port     uint16   `json:"port"`
}
type ShadowsocksServerConfig struct {
	Cipher      string                   `json:"method"`
	Password    string                   `json:"password"`
	Level       byte                     `json:"level"`
	Email       string                   `json:"email"`
	Users       []*ShadowsocksUserConfig `json:"users"`
	Clients     []*ShadowsocksUserConfig `json:"clients"`
	NetworkList *NetworkList             `json:"network"`
}
type ShadowsocksServerTarget struct {
	Address  *Address `json:"address"`
	Port     uint16   `json:"port"`
	Level    byte     `json:"level"`
	Email    string   `json:"email"`
	Cipher   string   `json:"method"`
	Password string   `json:"password"`
}
type ShadowsocksClientConfig struct {
	Address  *Address                   `json:"address"`
	Port     uint16                     `json:"port"`
	Level    byte                       `json:"level"`
	Email    string                     `json:"email"`
	Cipher   string                     `json:"method"`
	Password string                     `json:"password"`
	Servers  []*ShadowsocksServerTarget `json:"servers"`
}

func (*ShadowsocksServerConfig) Build() (proto.Message, error) {
	return nil, errors.New("Shadowsocks server is unavailable in the iOS build")
}
func (v *ShadowsocksClientConfig) Build() (proto.Message, error) {
    if v.Address == nil || v.Port == 0 || v.Cipher != "2022-blake3-aes-128-gcm" || v.Password == "" || len(v.Servers) != 0 {
        return nil, errors.New("unsupported iOS Shadowsocks client configuration")
    }
    return &ss2022.ClientConfig{Address: v.Address.Build(), Port: uint32(v.Port),
        Method: v.Cipher, Key: v.Password}, nil
}
